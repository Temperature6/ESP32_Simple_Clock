#include <Arduino.h>

extern uint8_t Char_Week[7][32];
extern uint8_t Char_XingQi[2][32];
extern uint8_t Icon_Sun[60];
extern uint8_t Icon_Moon[60];
extern uint8_t Icon_Temp[32];
extern uint8_t Icon_Humt[32];
extern uint8_t Icon_Up[32];
extern uint8_t Icon_Down[32];
